echo "Descargando servicio"
mkdir "temp"
nuget install FlexygoService -OutputDirectory ./temp -Source https://packages.nuget.org/api/v2

echo "Moviendo carpeta"
cd "./temp/FlexyGoService.*"
ren content FlexyGoService
move "./FlexyGoService" "%programfiles(x86)%\"

echo "Eliminando temporales"
cd ..
cd ..
rmdir /S /Q temp

echo "Instalando servicio"
"%programfiles(x86)%\flexygoservice\flexygoservice.exe" /i

echo "Iniciando servicio"
net start FlexyGoService

pause