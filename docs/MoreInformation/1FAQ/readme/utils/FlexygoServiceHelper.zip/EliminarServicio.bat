echo "Desinstalando servicio"
"%programfiles(x86)%\flexygoservice\flexygoservice.exe" /u

echo "Borrando carpeta"
rmdir /S /Q "%programfiles(x86)%\FlexyGoService\"

pause